#!/bin/sh

../../main/radeapclient -x localhost auth testing123 <eapsim-in.txt



