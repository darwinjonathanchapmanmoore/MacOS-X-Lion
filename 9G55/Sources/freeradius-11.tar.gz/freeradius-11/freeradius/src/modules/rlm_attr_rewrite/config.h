/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the <regex.h> header file.  */
#define HAVE_REGEX_H 1
