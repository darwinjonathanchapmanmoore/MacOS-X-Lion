/* do we need GDBM_SYNC */
#undef NEED_GDBM_SYNC

/* do we have gdbm_fdesc */
#undef HAVE_GDBM_FDESC
