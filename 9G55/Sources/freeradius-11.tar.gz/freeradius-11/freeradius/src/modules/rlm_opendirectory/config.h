/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the <crypt.h> header file. */
/* #undef HAVE_CRYPT_H */

/* Define if you have the `fgetgrent' function. */
/* #undef HAVE_FGETGRENT */

/* Define if you have the `fgetpwent' function. */
/* #undef HAVE_FGETPWENT */

/* Define if you have the `fgetspent' function. */
/* #undef HAVE_FGETSPENT */

/* Define if you have the `getspnam' function. */
/* #undef HAVE_GETSPNAM */

/* Define if you have the `getusershell' function. */
#define HAVE_GETUSERSHELL 1

/* Define if you have the <shadow.h> header file. */
/* #undef HAVE_SHADOW_H */
