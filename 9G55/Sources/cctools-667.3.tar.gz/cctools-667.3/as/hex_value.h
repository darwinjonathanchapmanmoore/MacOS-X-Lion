extern char hex_value[];
