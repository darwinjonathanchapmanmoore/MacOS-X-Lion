#!/bin/sh
mkdir -p "$DERIVED_SOURCES_DIR/IOKit" && ln -sf "$SRCROOT/pccard" "$DERIVED_SOURCES_DIR/IOKit/pccard"
