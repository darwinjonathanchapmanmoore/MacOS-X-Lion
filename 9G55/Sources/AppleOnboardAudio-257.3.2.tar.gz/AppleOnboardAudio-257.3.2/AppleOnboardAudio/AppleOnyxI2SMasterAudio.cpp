/*
 *  AppleOnyxI2SMasterAudio.cpp
 *  AppleOnboardAudio
 *
 *  Created by AudioSW Team on Friday 14 May 2004.
 *  Copyright (c) 2003 Apple. All rights reserved.
 *
 */

#include "AppleOnyxI2SMasterAudio.h"
#include "PlatformInterface.h"
#include "AudioHardwareUtilities.h"



