/*
 *  AppleToonieAudio.cpp
 *  AppleOnboardAudio
 *
 *  Created by the Audio Team! on Wed Apr 14 2004.
 *  Copyright (c) 2004 AppleComputer, Inc. All rights reserved.
 *
 */

#include "AppleToonieAudio.h"
#include "PlatformInterface.h"
#include "AudioHardwareUtilities.h"

