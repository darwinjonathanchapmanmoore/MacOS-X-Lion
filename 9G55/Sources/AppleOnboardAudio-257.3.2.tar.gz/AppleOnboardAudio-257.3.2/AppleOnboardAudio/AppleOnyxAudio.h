/*
 *  AppleOnyxAudio.h
 *  AppleOnboardAudio
 *
 *  Created by AudioSW Team on Mon Jun 16 2003.
 *  Copyright (c) 2003 AppleComputer. All rights reserved.
 *
 */

#include "AudioHardwareObjectInterface.h"
#include "Onyx_hw.h"
#include "PlatformInterface.h"
#include "AppleDBDMAAudio.h"
#include "AppleOnboardAudio.h"
#include "AppleOnboardAudioUserClient.h"


