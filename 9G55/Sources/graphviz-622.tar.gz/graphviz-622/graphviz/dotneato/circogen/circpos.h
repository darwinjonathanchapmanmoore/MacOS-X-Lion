#ifndef CIRCPOS_H
#define CIRCPOS_H

#include <render.h>
#include <circular.h>

extern void circPos(Agraph_t* g, block_t* sn, circ_state*);

#endif
