#pragma prototyped

#ifndef _C2L_H
#define _C2L_H
int C2Lopen (char *, char *, FILE **, FILE **);
#endif /* _C2L_H */
