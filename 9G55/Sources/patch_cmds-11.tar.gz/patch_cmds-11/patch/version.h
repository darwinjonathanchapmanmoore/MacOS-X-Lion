/* Print the version number.  */

/* $Id: version.h,v 1.1.1.3 2003/05/08 18:38:04 rbraun Exp $ */

void version (void);
