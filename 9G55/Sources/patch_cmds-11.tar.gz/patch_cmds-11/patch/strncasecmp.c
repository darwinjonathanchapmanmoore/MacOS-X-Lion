#define LENGTH_LIMIT
#include "strcasecmp.c"
