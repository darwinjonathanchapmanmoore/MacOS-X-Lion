"""
Proxy65: A jabberd socks5 bytestream file transfer module.
"""
