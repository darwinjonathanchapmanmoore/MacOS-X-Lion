<?php

# This code is inserted into example.php
echo "this is include.php\n";


?>
