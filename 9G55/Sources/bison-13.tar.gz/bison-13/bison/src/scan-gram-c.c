#include <config.h>
#include "scan-gram.c"
