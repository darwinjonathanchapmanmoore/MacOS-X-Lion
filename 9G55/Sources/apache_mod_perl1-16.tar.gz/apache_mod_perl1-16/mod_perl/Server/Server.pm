package Apache::Server;

use mod_perl ();

$VERSION = '1.01';
__PACKAGE__->mod_perl::boot($VERSION);

1;
__END__
