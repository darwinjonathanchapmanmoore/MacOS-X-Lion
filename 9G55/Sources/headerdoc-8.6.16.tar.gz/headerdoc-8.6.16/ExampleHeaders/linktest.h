/*! @header foo.h
    @discussion For more information, see <A HREF="@docroot/index.html">the index</A> or {@link //apple_ref/occ//ObjCClassDeux/classTwoMethodFour:bogusOne:bogusTwo classTwoMethodFour documentation} if you'd like.
 */


/*! @class fooclass
 */
class fooclass
{

/*!
	This is a link to {@link foo foo}.  And {@link //apple_ref/cpp/instm/IOService/getDeviceMemoryWithIndex/virtualIODeviceMemory*\/(unsignedint) vdm}
 */
void *bar(int *bar);

/*!
	This is a link to {@link bar bar}.
 */
void *foo(int *foo);

};

