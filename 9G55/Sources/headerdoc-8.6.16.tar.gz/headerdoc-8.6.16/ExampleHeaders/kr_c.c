
/*! @function ansifunc
    @discussion test of ANSI C and K&R C mixed.
 */
void ansifunc(int a, void b);

/*! @function main
    @discussion doesn't do much
*/

main(a, b)
int a;
char *b;
{
int c;





}
