
/*! @class outer
    @discussion outer class
 */

class outer
{

/*! @function outerfunc_1 */
void outerfunc_1(int b);

/*! @class inner
    @discussion inner class
 */
class inner
{

/*! @function innerfunc */
char *innerfunc(int a);


};

/*! @function outerfunc_2
 */
long outerfunc_2(int c);


};

