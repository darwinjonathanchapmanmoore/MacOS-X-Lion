/*! @header
    @discussion

	This is an example of how to use a textblock element.

	<pre>
	@textblock
	if (a<3) {
		printf("a is less than 3.\n");
	}
	@/textblock
	</pre>

	For more information, reread this page.
 */

