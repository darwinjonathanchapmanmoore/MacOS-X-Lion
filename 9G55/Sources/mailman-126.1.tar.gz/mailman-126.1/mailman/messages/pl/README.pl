Projekt polonizacji Mailmana rozpocz�� si� w kwietniu 2001. 

Oficjaln� stron� t�umaczenia jest: (strona praktycznie martwa)
http://linux.gda.pl/pub/Mailman-pl/

Lista dyskusyjna polskich t�umaczy: (lista praktycznie martwa)
http://linux.gda.pl/mailman/listinfo/mailman-pl

Do tej pory w t�umaczeniu pomagali (w kolejno�ci chronologicznej):
- Marcin Sochacki <wanted%linux.gda.pl>
- Pawe� Ko�odziejczyk <Pawel.Kolodziejczyk%comarch.pl>
- Marcin Zaborowski <m.zaborowski%il.pw.edu.pl>
- Wojciech Czarnowski <wojtekcz%rodos.com.pl>
- Bartosz Sawicki <sawickib%iem.pw.edu.pl>
- Robert �wi�cki <rswieck1%elka.pw.edu.pl>
- Pawe� Go�aszewski <blues%ds.pg.gda.pl>
- Tomasz Toczyski <Tomasz.Toczyski%isep.pw.edu.pl>

W chwili obecnej przet�umaczone jest 99% interfejsu subskrybenta i oko�o 
95% interfejsu administracyjnego. Najbardziej aktualnej wersji szukajcie w
oficjalnych CVS Mailmana. 

Do zrobienia:
- szlifowanie, polerowanie :)
- sko�czenie t�umaczenia mailman.po (zosta�o jeszcze 230 msgid)
- przet�umaczenie README.* dla r�nych MTA

2005-10-11, Bartosz Sawicki <sawickib@iem.pw.edu.pl>
