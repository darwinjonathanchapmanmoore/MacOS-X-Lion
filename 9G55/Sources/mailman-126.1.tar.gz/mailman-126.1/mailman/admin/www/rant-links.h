<!-- -*- html -*- -->
<h3>Rants</h3>
<li><a href="jwzrebuttal.html">Mailman Considered Beneficial</a>
