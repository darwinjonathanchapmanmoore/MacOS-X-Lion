void func(void* x) {}
