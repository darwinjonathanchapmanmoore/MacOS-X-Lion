

int __attribute__((visibility("hidden"))) myglobal = 3;
int __attribute__((visibility("hidden"))) myglobal2 = 3;
int __attribute__((visibility("hidden"))) xmyglobal = 3;
int __attribute__((visibility("hidden"))) xmyglobal2 = 3;

void __attribute__((visibility("hidden"))) myfunction(int x) { }



