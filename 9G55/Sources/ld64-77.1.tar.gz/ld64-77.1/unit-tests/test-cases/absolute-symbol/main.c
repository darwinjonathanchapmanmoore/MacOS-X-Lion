
extern int* myAbs;

int main() { return *myAbs; }

