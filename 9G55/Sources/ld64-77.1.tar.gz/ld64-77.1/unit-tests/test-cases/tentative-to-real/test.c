
// a tentative definition
int a;
