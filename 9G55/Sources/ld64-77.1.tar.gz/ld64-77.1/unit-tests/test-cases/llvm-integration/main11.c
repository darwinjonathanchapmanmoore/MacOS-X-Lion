
extern void foo3(void);
int main()
{
  foo3();
  return 0;
}
