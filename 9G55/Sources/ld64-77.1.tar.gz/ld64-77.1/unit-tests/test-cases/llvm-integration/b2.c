extern int foo4(void);

int foo4(void)
{
  return 21;
}
int foo2() {
	return foo4();
}
