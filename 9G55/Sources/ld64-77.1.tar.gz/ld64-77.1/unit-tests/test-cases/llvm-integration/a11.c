#include <stdio.h>
void foo3(void)
{
  fputc ('x', stderr);
  printf ("\n");
}
