int ddd_common;
int iii_common[4];
int bbb_common[4];
