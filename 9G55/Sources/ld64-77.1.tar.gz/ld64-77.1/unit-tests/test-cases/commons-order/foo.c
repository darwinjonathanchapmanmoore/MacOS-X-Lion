int aaa_common;
int ggg_common[4];
int eee_common;
