extern int foo ();
extern int bar ();
extern int baz ();

int main (void)
{
  return foo() + bar() + baz();
}
