
extern void foo();
extern void bar();

extern void aaa();
extern void bbb();


int main()
{
	foo();
	bar();
	aaa();
	bbb();
	
	return 0;
}
