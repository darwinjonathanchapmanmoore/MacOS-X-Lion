#include "vms.h"
#define VMS4_4

#undef NO_HYPHENS_IN_FILENAMES

/* arch-tag: 2e65c7ad-0d17-45a0-b4cb-3e76c72ea9d5
   (do not change this comment) */
