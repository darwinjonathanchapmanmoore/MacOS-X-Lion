/* System description file for Windows 95.  */

#include "windowsnt.h"

#define WINDOWS95

/* arch-tag: 8a37be6f-312c-4b2a-919e-58a71a0fb4b3
   (do not change this comment) */
