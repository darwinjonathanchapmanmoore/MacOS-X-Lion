/*
 * The code here is forced by the interface, and is not subject to
 * copyright, constituting the only possible expression of the
 * algorithm in this format.
 */
#define	CHP$_END	0
#define	CHP$_ACCESS	1
#define	CHP$_FLAGS	2
#define	CHP$_PRIV	3
#define	CHP$_ACMODE	4
#define	CHP$_ACCLASS	5
#define	CHP$_RIGHTS	6
#define	CHP$_ADDRIGHTS	7
#define	CHP$_MODE	8
#define	CHP$_MODES	9
#define	CHP$_MINCLASS	10
#define	CHP$_MAXCLASS	11
#define	CHP$_OWNER	12
#define	CHP$_PROT	13
#define	CHP$_ACL	14
#define	CHP$_AUDITNAME	15
#define	CHP$_ALARMNAME	16
#define	CHP$_MATCHEDACE	17
#define	CHP$_PRIVUSED	18
#define	CHP$_MAX_CODE	19
#define	CHP$M_SYSPRV	1
#define	CHP$M_BYPASS	2
#define	CHP$M_UPGRADE	4
#define	CHP$M_DOWNGRADE	8
#define	CHP$M_GRPPRV	16
#define	CHP$M_READALL	32
#define	CHP$V_SYSPRV	0
#define	CHP$V_BYPASS	1
#define	CHP$V_UPGRADE	2
#define	CHP$V_DOWNGRADE	3
#define	CHP$V_GRPPRV	4
#define	CHP$V_READALL	5
#define	CHP$M_READ	1
#define	CHP$M_WRITE	2
#define	CHP$M_USEREADALL	4
#define	CHP$V_READ	0
#define	CHP$V_WRITE	1
#define	CHP$V_USEREADALL	2

/* arch-tag: a7117984-e927-4f8e-932e-35d5fd524f12
   (do not change this comment) */
