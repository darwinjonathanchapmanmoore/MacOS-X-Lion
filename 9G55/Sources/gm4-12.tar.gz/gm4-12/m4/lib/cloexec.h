#include <stdbool.h>
int set_cloexec_flag (int desc, bool value);
