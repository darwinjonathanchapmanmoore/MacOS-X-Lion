int
timeval_subtract(struct timeval *result,
		 struct timeval *x,
		 struct timeval *y);
