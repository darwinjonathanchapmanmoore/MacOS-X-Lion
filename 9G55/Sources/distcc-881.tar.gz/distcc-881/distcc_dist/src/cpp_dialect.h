
extern int dcc_seen_opt_x;
extern char *dcc_opt_x_ext;

char *dcc_ext_lookup(char *key);
void dcc_fix_opt_x(char **argv);
